package com.capgi.PolicyService.Repo;

import java.util.List;

import org.springframework.data.jpa.repository.JpaRepository;

import com.capgi.PolicyService.Entity.Policy;

public interface PolicyRepo extends JpaRepository<Policy, Integer>{
	
	public List<Policy> findByApplicablegender(String applicablegender);

}
