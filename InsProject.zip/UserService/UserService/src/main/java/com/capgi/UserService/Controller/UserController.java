package com.capgi.UserService.Controller;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import com.capgi.UserService.Entity.User;
import com.capgi.UserService.Payloades.UserDTO;
import com.capgi.UserService.Service.UserService;

@RestController
@RequestMapping("/insurance/users")
public class UserController {
	
	@Autowired
	private UserService userService;
	
	@PostMapping("/createuser")
	public ResponseEntity<User> createUser(@RequestBody User user){
		
		User newUser = userService.createNewUser(user);
		
		return new ResponseEntity<>(newUser, HttpStatus.CREATED);
		
	}
	
	@GetMapping("/getuser/{id}")
	public ResponseEntity<UserDTO> getUser(@PathVariable int id ){
		UserDTO user = userService.getUserById(id);
		return new ResponseEntity<>(user, HttpStatus.FOUND);
		
	}
	
	@PostMapping("/updatetoadmin/{id}")
	public ResponseEntity<UserDTO> updateUserToAdmin(@PathVariable int id){
		UserDTO user = userService.updateUserToAdmin(id);
		return new ResponseEntity<>(user, HttpStatus.OK) ;
		
	}
}
