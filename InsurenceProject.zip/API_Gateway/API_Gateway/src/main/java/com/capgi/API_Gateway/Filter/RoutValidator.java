package com.capgi.API_Gateway.Filter;

import java.util.List;
import java.util.function.Predicate;

import org.springframework.http.server.reactive.ServerHttpRequest;
import org.springframework.stereotype.Component;

@Component
public class RoutValidator {

    public static final List<String> ALLOWED_ENDPOINTS = List.of(
            "/auth/generateToken",
            "/insurance/users/getuser/",
            "/insurance/users/createuser",
            "/eureka"
    );

    public Predicate<ServerHttpRequest> isSecured = 
            request -> ALLOWED_ENDPOINTS
                    .stream()
                    .noneMatch(uri -> request.getURI().getPath().contains(uri));
}
