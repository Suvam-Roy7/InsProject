package com.capgi.UserService.Controller;


import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.security.authentication.AuthenticationManager;
import org.springframework.security.authentication.UsernamePasswordAuthenticationToken;
import org.springframework.security.core.Authentication;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.RestController;

import com.capgi.UserService.Entity.UserCredentials;
import com.capgi.UserService.Service.UserService;

@RestController
@RequestMapping("/auth")
public class AuthController {
	
	@Autowired
	private UserService userService;
	
	@Autowired
	private AuthenticationManager authenticationManager;
	
	@PostMapping("/generateToken")
	public ResponseEntity<String> getToken(@RequestBody UserCredentials user){
		try {
			authenticationManager.authenticate(new UsernamePasswordAuthenticationToken(user.getUsername(), user.getPassword()));
			String token = userService.generateToken(user.getUsername());
			return new ResponseEntity<>(token, HttpStatus.OK) ;
		}catch(Exception e) {
			throw new RuntimeException("User with username : "+user.getUsername()+" and password : "+user.getPassword()+ " is not Registered");
		}
		
	}
	
	@GetMapping("/validateToken")
	public ResponseEntity<String> validateToken(@RequestParam("token") String token){
		userService.validateToken(token);
		return new ResponseEntity<>("Token is valid", HttpStatus.OK) ;
	}

}
