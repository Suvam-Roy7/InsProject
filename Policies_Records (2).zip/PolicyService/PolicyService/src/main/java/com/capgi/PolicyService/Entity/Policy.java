package com.capgi.PolicyService.Entity;

import jakarta.persistence.Entity;
import jakarta.persistence.GeneratedValue;
import jakarta.persistence.GenerationType;
import jakarta.persistence.Id;

@Entity
public class Policy {
	
	@Id
	@GeneratedValue(strategy = GenerationType.AUTO)
	private int policyid; 
	private String policyname;
	private String policytype;
	private String applicablegender;
	private int minAge;
	private int maxAge;
	private int quaterlyPrice;
	private int halfYearPrice;
	private int annualPrice;
	
	
	
	public Policy(int policyid, String policyname, String policytype, String applicablegender, int minAge, int maxAge,
			int quaterlyPrice, int halfYearPrice, int annualPrice) {
		super();
		this.policyid = policyid;
		this.policyname = policyname;
		this.policytype = policytype;
		this.applicablegender = applicablegender;
		this.minAge = minAge;
		this.maxAge = maxAge;
		this.quaterlyPrice = quaterlyPrice;
		this.halfYearPrice = halfYearPrice;
		this.annualPrice = annualPrice;
	}

	

	public Policy() {
		super();
	}



	public int getMinAge() {
		return minAge;
	}



	public void setMinAge(int minAge) {
		this.minAge = minAge;
	}



	public int getMaxAge() {
		return maxAge;
	}



	public void setMaxAge(int maxAge) {
		this.maxAge = maxAge;
	}



	public int getPolicyid() {
		return policyid;
	}

	public void setPolicyid(int policyid) {
		this.policyid = policyid;
	}

	public String getPolicyname() {
		return policyname;
	}

	public void setPolicyname(String policyname) {
		this.policyname = policyname;
	}

	public String getPolicytype() {
		return policytype;
	}

	public void setPolicytype(String policytype) {
		this.policytype = policytype;
	}

	public int getQuaterlyPrice() {
		return quaterlyPrice;
	}

	public void setQuaterlyPrice(int quaterlyPrice) {
		this.quaterlyPrice = quaterlyPrice;
	}

	public int getHalfYearPrice() {
		return halfYearPrice;
	}

	public void setHalfYearPrice(int halfYearPrice) {
		this.halfYearPrice = halfYearPrice;
	}

	public int getAnnualPrice() {
		return annualPrice;
	}

	public void setAnnualPrice(int annualPrice) {
		this.annualPrice = annualPrice;
	}



	public String getApplicablegender() {
		return applicablegender;
	}



	public void setApplicablegender(String applicablegender) {
		this.applicablegender = applicablegender;
	}
	
}
