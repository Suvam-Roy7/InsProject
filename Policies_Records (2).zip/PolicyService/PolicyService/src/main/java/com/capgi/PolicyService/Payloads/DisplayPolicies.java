package com.capgi.PolicyService.Payloads;

import java.util.List;

import com.capgi.PolicyService.Entity.Policy;

public class DisplayPolicies {
	
	private String username;
	private int userage;
	private String usersex;
	private List<Policy> policies;
	
	public DisplayPolicies(String username, int userage, String usersex, List<Policy> policies) {
		super();
		this.username = username;
		this.userage = userage;
		this.usersex = usersex;
		this.policies = policies;
	}

	public DisplayPolicies() {
		super();
	}

	public String getUsername() {
		return username;
	}

	public void setUsername(String username) {
		this.username = username;
	}

	public int getUserage() {
		return userage;
	}

	public void setUserage(int userage) {
		this.userage = userage;
	}

	public String getUsersex() {
		return usersex;
	}

	public void setUsersex(String usersex) {
		this.usersex = usersex;
	}

	public List<Policy> getPolicies() {
		return policies;
	}

	public void setPolicies(List<Policy> policies) {
		this.policies = policies;
	}

}
