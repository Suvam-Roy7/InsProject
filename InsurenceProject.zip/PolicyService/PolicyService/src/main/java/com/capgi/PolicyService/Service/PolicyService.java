package com.capgi.PolicyService.Service;


import java.util.ArrayList;
import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.web.client.RestTemplate;

import com.capgi.PolicyService.Entity.Policy;
import com.capgi.PolicyService.Entity.User;
import com.capgi.PolicyService.Exception.ResourceNotFoundException;
import com.capgi.PolicyService.Payloads.DisplayPolicies;
import com.capgi.PolicyService.Repo.PolicyRepo;

import org.springframework.http.HttpEntity;
import org.springframework.http.HttpHeaders;
import org.springframework.http.HttpMethod;
import org.springframework.http.ResponseEntity;


@Service
public class PolicyService {
	
	@Autowired
	private PolicyRepo policyRepo;
	
	@Autowired
	private RestTemplate restTemplate;

	public Policy createNewPolicy(Policy policy) {
		
		Policy policyy =  policyRepo.save(policy);
		
		return policyy;
	}

	public Policy getPolicyById(int policyid) {
		
		Policy policyy = policyRepo.findById(policyid).orElseThrow(() -> new ResourceNotFoundException("Policy", "id", policyid));
		
		return policyy;
	}

	public DisplayPolicies showAllPoliciesAvlForUser(int userid, String policyType) {
		
		User user = restTemplate.getForObject("http://AUTHENTICATION-SERVICE/insurance/users/getuser/"+userid, User.class);
	
		DisplayPolicies displayPolicies = new DisplayPolicies();
		displayPolicies.setUsername(user.getUsername());
		displayPolicies.setUsersex(user.getGender());
		displayPolicies.setUserage(user.getAge());
		
		List<Policy> policies = policyRepo.findByApplicablegender(user.getGender());
		List<Policy> policiesUnisex = policyRepo.findByApplicablegender("UNISEX");
		policies.addAll(policiesUnisex);
		
		List<Policy> applicablePolicies = new ArrayList<>();
		
		for(Policy pol : policies) {
			
			if(policyType.equalsIgnoreCase("All") && (user.getAge() >= pol.getMinAge() && user.getAge() < pol.getMaxAge())) {
				
				if(user.getAge() >= 18 && user.getAge() < 35 && user.getGender().equalsIgnoreCase("MALE")) {
					int quaterlyPrice = pol.getQuaterlyPrice();
					int halfYearPrice = pol.getHalfYearPrice();
					int annualPrice = pol.getAnnualPrice();
					
					pol.setQuaterlyPrice(quaterlyPrice - ((quaterlyPrice/100)*5));
					pol.setHalfYearPrice(halfYearPrice - ((halfYearPrice/100)*5));
					pol.setAnnualPrice(annualPrice - ((annualPrice/100)*5));
				}
				else if(user.getAge() >= 18 && user.getAge() < 35 && user.getGender().equalsIgnoreCase("FEMALE")) {
					int quaterlyPrice = pol.getQuaterlyPrice();
					int halfYearPrice = pol.getHalfYearPrice();
					int annualPrice = pol.getAnnualPrice();
					
					pol.setQuaterlyPrice(quaterlyPrice - ((quaterlyPrice/100)*10));
					pol.setHalfYearPrice(halfYearPrice - ((halfYearPrice/100)*10));
					pol.setAnnualPrice(annualPrice - ((annualPrice/100)*10));
				}
				else if(user.getAge() > 35 ) {
					int quaterlyPrice = pol.getQuaterlyPrice();
					int halfYearPrice = pol.getHalfYearPrice();
					int annualPrice = pol.getAnnualPrice();
					
					pol.setQuaterlyPrice(quaterlyPrice - ((quaterlyPrice/100)*20));
					pol.setHalfYearPrice(halfYearPrice - ((halfYearPrice/100)*20));
					pol.setAnnualPrice(annualPrice - ((annualPrice/100)*20));
				}
				
				applicablePolicies.add(pol);
			}
			else if(policyType.equalsIgnoreCase(pol.getPolicytype()) && (user.getAge() >= pol.getMinAge() && user.getAge() < pol.getMaxAge())) {
				
				if(user.getAge() >= 18 && user.getAge() < 35 && user.getGender().equalsIgnoreCase("MALE")) {
					int quaterlyPrice = pol.getQuaterlyPrice();
					int halfYearPrice = pol.getHalfYearPrice();
					int annualPrice = pol.getAnnualPrice();
					
					pol.setQuaterlyPrice(quaterlyPrice - ((quaterlyPrice/100)*5));
					pol.setHalfYearPrice(halfYearPrice - ((halfYearPrice/100)*5));
					pol.setAnnualPrice(annualPrice - ((annualPrice/100)*5));
				}
				else if(user.getAge() >= 18 && user.getAge() < 35 && user.getGender().equalsIgnoreCase("FEMALE")) {
					int quaterlyPrice = pol.getQuaterlyPrice();
					int halfYearPrice = pol.getHalfYearPrice();
					int annualPrice = pol.getAnnualPrice();
					
					pol.setQuaterlyPrice(quaterlyPrice - ((quaterlyPrice/100)*10));
					pol.setHalfYearPrice(halfYearPrice - ((halfYearPrice/100)*10));
					pol.setAnnualPrice(annualPrice - ((annualPrice/100)*10));
				}
				else if(user.getAge() > 35 ) {
					int quaterlyPrice = pol.getQuaterlyPrice();
					int halfYearPrice = pol.getHalfYearPrice();
					int annualPrice = pol.getAnnualPrice();
					
					pol.setQuaterlyPrice(quaterlyPrice - ((quaterlyPrice/100)*20));
					pol.setHalfYearPrice(halfYearPrice - ((halfYearPrice/100)*20));
					pol.setAnnualPrice(annualPrice - ((annualPrice/100)*20));
				}
				
				applicablePolicies.add(pol);
			}
			
		}
		
		displayPolicies.setPolicies(applicablePolicies);
		
		
		return displayPolicies;
	}
	

}
