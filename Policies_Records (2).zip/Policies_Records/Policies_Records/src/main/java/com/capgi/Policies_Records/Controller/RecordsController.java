package com.capgi.Policies_Records.Controller;

import java.io.IOException;
import java.io.InputStream;
import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.RestController;
import org.springframework.web.multipart.MultipartFile;

import com.capgi.Policies_Records.Service.FileService;
import com.capgi.Policies_Records.Service.RecordsService;

import jakarta.servlet.http.HttpServletResponse;

import com.capgi.Policies_Records.Entity.Record;
import com.capgi.Policies_Records.Payloads.SuscribePolicy;
import org.springframework.http.MediaType;
import org.springframework.util.StreamUtils;

@RestController
@RequestMapping("/records")
public class RecordsController {
	
	@Autowired
	private RecordsService recordsService;
	
	@Autowired
	private FileService fileService;
	
	@Value("${projectImageStorePath}")
	private String path; 
	
	@PostMapping("/suscribepolicy")
	public ResponseEntity<Record> suscribePolicy(@RequestBody SuscribePolicy suscribePolicy){
		
		Record rec = recordsService.suscribePolicy(suscribePolicy);
		
		return new ResponseEntity<>(rec, HttpStatus.CREATED);
	}
	

	@GetMapping("/getallrecords")
	public ResponseEntity<List<Record>> getAllRecords(){
		
		List<Record> records = recordsService.getAllRecords();
		
		return new ResponseEntity<>(records, HttpStatus.OK);
	}
	
	@GetMapping("/getuserrecords/{userid}")
	public ResponseEntity<List<Record>> getUserRecords(@PathVariable int userid){
		
		List<Record> records = recordsService.getUserRecords(userid);
		
		return new ResponseEntity<>(records, HttpStatus.OK);
	}
	
	@PostMapping("/image-upload/{recordId}")
	public ResponseEntity<Record> uploadImage(
			@PathVariable("recordId") Integer recordId,
			@RequestParam("image") MultipartFile image
			) throws Exception{
		
		Record rec = recordsService.getRecordById(recordId);
		String imageName = fileService.uploadImageFile(path, image);
		rec.setAddharImg(imageName);
		Record updatedRec = recordsService.updateRecord(recordId, rec);
		
		return new ResponseEntity<>(updatedRec, HttpStatus.OK);
	}
	
	@GetMapping("/get-image/{imageName}")
	public void downloadImage(@PathVariable("imageName") String imageName, HttpServletResponse response) throws IOException {
		
		InputStream resource = fileService.getResource(path, imageName);
		response.setContentType(MediaType.IMAGE_JPEG_VALUE);
		StreamUtils.copy(resource, response.getOutputStream());
	}

}
