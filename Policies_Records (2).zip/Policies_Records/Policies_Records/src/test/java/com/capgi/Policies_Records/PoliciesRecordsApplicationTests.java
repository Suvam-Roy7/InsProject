package com.capgi.Policies_Records;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class PoliciesRecordsApplicationTests {

	@Test
	void contextLoads() {
	}

}
