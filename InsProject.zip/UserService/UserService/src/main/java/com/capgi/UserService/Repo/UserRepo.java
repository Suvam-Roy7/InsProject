package com.capgi.UserService.Repo;

import org.springframework.data.jpa.repository.JpaRepository;

import com.capgi.UserService.Entity.User;

public interface UserRepo extends JpaRepository<User, Integer> {
	

}
