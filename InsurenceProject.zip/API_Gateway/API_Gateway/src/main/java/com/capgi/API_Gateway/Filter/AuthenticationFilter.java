package com.capgi.API_Gateway.Filter;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.cloud.gateway.filter.GatewayFilter;
import org.springframework.cloud.gateway.filter.factory.AbstractGatewayFilterFactory;
import org.springframework.stereotype.Component;
import org.springframework.web.client.RestTemplate;

import jakarta.ws.rs.core.HttpHeaders;

@Component
public class AuthenticationFilter extends AbstractGatewayFilterFactory<AuthenticationFilter.Config>{
	
	@Autowired
	private RoutValidator validator;
	
	@Autowired
	private RestTemplate restTemplate;
	
	@Autowired
	private JWTutil jwtutil;
	
	public AuthenticationFilter() {
        super(Config.class);
    }

    @Override
    public GatewayFilter apply(Config config) {
        return (exchange, chain) -> {
        	
        	if(validator.isSecured.test(exchange.getRequest())) {
        		if(!exchange.getRequest().getHeaders().containsKey(HttpHeaders.AUTHORIZATION)) {
        			throw new RuntimeException("missing autherization header");
        		}
        	}
        	
        	String authHeader = exchange.getRequest().getHeaders().get(HttpHeaders.AUTHORIZATION).get(0);
            if(authHeader!=null && authHeader.startsWith("Bearer ")) {
            	authHeader = authHeader.substring(7); 
            }
        	System.out.println(authHeader);
        	
        	try {
        		//restTemplate.getForObject("http://AUTHENTICATION-SERVICE/auth/validateToken?token="+authHeader, String.class);
        		jwtutil.vaildateToken(authHeader);
        	}catch(Exception e) {
        		throw new RuntimeException("Unauthorized to application");
        	}
            return chain.filter(exchange);
        };
    }

    public static class Config {
        // Configuration properties for your filter (if any)
    }
}
