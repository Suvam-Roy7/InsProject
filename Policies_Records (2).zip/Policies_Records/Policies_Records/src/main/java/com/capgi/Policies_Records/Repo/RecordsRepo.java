package com.capgi.Policies_Records.Repo;

import java.util.List;
import com.capgi.Policies_Records.Entity.Record;

import org.springframework.data.jpa.repository.JpaRepository;

public interface RecordsRepo extends JpaRepository<Record, Integer>{
	
	public List<Record> findAllByUserid(int userid);

}
