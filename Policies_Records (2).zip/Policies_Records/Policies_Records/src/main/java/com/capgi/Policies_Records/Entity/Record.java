package com.capgi.Policies_Records.Entity;

import java.util.Date;

import jakarta.persistence.Entity;
import jakarta.persistence.GeneratedValue;
import jakarta.persistence.GenerationType;
import jakarta.persistence.Id;

@Entity
public class Record {
	
	@Id
	@GeneratedValue(strategy = GenerationType.AUTO)
	private int rec_id;
	private int policyid;
	private int userid;
	private Date  sub_date;
	private Date exp_date;
	private long addhar_card;
	private String status;
	private String addharImg;
	
	
	
	public String getAddharImg() {
		return addharImg;
	}
	public void setAddharImg(String addharImg) {
		this.addharImg = addharImg;
	}
	public int getRecid() {
		return rec_id;
	}
	public void setRecid(int recid) {
		this.rec_id = recid;
	}
	public int getPolicyid() {
		return policyid;
	}
	public void setPolicyid(int policyid) {
		this.policyid = policyid;
	}
	public int getUserid() {
		return userid;
	}
	public void setUserid(int userid) {
		this.userid = userid;
	}
	public Date getSub_date() {
		return sub_date;
	}
	public void setSub_date(Date sub_date) {
		this.sub_date = sub_date;
	}
	public Date getExp_date() {
		return exp_date;
	}
	public void setExp_date(Date exp_date) {
		this.exp_date = exp_date;
	}
	public long getAddhar_card() {
		return addhar_card;
	}
	public void setAddhar_card(long addhar_card) {
		this.addhar_card = addhar_card;
	}
	public String getStatus() {
		return status;
	}
	public void setStatus(String status) {
		this.status = status;
	}
	public Record(int rec_id, int policy_id, int user_id, Date sub_date, Date exp_date, long addhar_card,
			String status) {
		super();
		this.rec_id = rec_id;
		this.policyid = policy_id;
		this.userid = user_id;
		this.sub_date = sub_date;
		this.exp_date = exp_date;
		this.addhar_card = addhar_card;
		this.status = status;
	}
	public Record() {
		super();
	}
	
}
