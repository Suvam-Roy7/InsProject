package com.capgi.UserService.Payloades;

import java.util.Optional;

import org.modelmapper.ModelMapper;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.security.core.userdetails.UserDetails;
import com.capgi.UserService.Entity.User;
import com.capgi.UserService.Entity.UserCredentials;

import org.springframework.security.core.userdetails.UserDetailsService;
import org.springframework.security.core.userdetails.UsernameNotFoundException;

import com.capgi.UserService.Repo.UserRepo;

public class CustomUserDetailService implements UserDetailsService{
	
	@Autowired
	private UserRepo userrepo;
	
	@Autowired
	private ModelMapper modelMapper;

	@Override
	public UserDetails loadUserByUsername(String username) throws UsernameNotFoundException {
		Optional<User> user = userrepo.findByUsername(username);
		UserCredentials userCredentials = modelMapper.map(user, UserCredentials.class);
		return userCredentials;
	}

}
