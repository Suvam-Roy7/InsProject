package com.capgi.UserService.Service;

import org.modelmapper.ModelMapper;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.security.crypto.password.PasswordEncoder;
import org.springframework.stereotype.Service;

import com.capgi.UserService.Entity.Role;
import com.capgi.UserService.Entity.User;
import com.capgi.UserService.Exception.ResourceNotFoundException;
import com.capgi.UserService.Payloades.UserDTO;
import com.capgi.UserService.Repo.RoleRepo;
import com.capgi.UserService.Repo.UserRepo;

@Service
public class UserService {
	
	@Autowired
	private UserRepo userRepo;
	
	@Autowired
	private RoleRepo roleRepo;
	
	@Autowired
	private PasswordEncoder passwordEncoder;
	
	@Autowired
	private JWT_Service jwtService;
	
	@Autowired
	private ModelMapper modelMapper;

	public User createNewUser(User user) {
		Role role = roleRepo.findById(2).orElseThrow(() -> new ResourceNotFoundException("Role", "id", 2));
		user.getRoles().add(role);
		user.setPassword(passwordEncoder.encode(user.getPassword()));
		User userNew = userRepo.save(user);
		return userNew;
	}

	public UserDTO getUserById(int id) {
		
		User user = userRepo.findById(id).orElseThrow(() -> new ResourceNotFoundException("User", "id", id));
		UserDTO userDTO = modelMapper.map(user, UserDTO.class);
		return userDTO;
	}

	public UserDTO updateUserToAdmin(int id) {
		
		User user = userRepo.findById(id).orElseThrow(() -> new ResourceNotFoundException("User", "id", id));
		Role role = roleRepo.findById(1).orElseThrow(() -> new ResourceNotFoundException("Role", "id", 1));
		user.getRoles().add(role);
		
		UserDTO userdto = modelMapper.map(user, UserDTO.class);
		return userdto;
	}
	
	public String generateToken( String  username) {
		return jwtService.generateToken(username);
	}
	
	public void validateToken(String token) {
		jwtService.vaildateToken(token);
	}
}
