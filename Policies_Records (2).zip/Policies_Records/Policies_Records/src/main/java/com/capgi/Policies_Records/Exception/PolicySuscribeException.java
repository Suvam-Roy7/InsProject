package com.capgi.Policies_Records.Exception;

public class PolicySuscribeException extends RuntimeException{
	
	int resourceName;
	int fieldValue;
	
	public PolicySuscribeException(int resourceName, int fieldValue) {
		super(String.format("Policy %s is already suscribed to user %s ", resourceName, fieldValue));
		this.resourceName = resourceName;
		this.fieldValue = fieldValue;
	}
}
