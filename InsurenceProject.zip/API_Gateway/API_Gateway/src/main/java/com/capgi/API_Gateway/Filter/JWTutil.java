package com.capgi.API_Gateway.Filter;

import java.util.Date;
import java.util.HashMap;
import java.util.Map;
import java.util.function.Function;

import org.springframework.stereotype.Component;

import io.jsonwebtoken.Claims;
import io.jsonwebtoken.Jwts;
import io.jsonwebtoken.SignatureAlgorithm;

@Component
public class JWTutil {
	// Constant created for token validity
			public static final long JWT_TOKEN_VALIDITY = 5 * 60 * 60;
			
			// Creating Secret Key
			public String secretKey = "jwtTokenSecretKey";
			
			private Claims getAllClaimsFromToken(String token){

		        return Jwts.parser().setSigningKey(secretKey).parseClaimsJws(token).getBody();

		    }
			
			public <T> T getClaimFromToken(String token, Function<Claims, T> claimsResolver) {
		        final Claims claims = getAllClaimsFromToken(token);
		        return claimsResolver.apply(claims);
		    }
			
			// Retrieve Username from token
			public String getUsernameFromToken(String token) {
				return getClaimFromToken(token, Claims::getSubject);
			}
			
			// Retrieve Expiration date from Token
			public Date getExpirationDateFromToken(String token) {
				return getClaimFromToken(token, Claims::getExpiration);
			}
			
			// Check if token has Expired
			public Boolean isTokenExpired(String token) {
				final Date expiration = getExpirationDateFromToken(token);
				return expiration.after(new Date());
			}
			
			
			
			// Validate Token
			public boolean vaildateToken(String token) {
				return isTokenExpired(token);
			}
}
