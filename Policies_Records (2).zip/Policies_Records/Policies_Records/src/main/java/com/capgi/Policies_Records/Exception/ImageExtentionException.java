package com.capgi.Policies_Records.Exception;

public class ImageExtentionException extends RuntimeException {
	
	private String fileName;
	
	public ImageExtentionException(String fileName) {
		super(String.format("%s cannot be uploaded. Only .png or .jpg allowed",fileName));
		this.fileName = fileName;
	}
}
