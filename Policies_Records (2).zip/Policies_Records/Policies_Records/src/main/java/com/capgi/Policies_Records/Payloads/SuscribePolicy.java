package com.capgi.Policies_Records.Payloads;

import java.util.Date;

public class SuscribePolicy {
	
	private int policyid;
	private int userid;
	private int duration;
	private long addhar_card;
	
	public int getPolicyid() {
		return policyid;
	}
	public void setPolicyid(int policy_id) {
		this.policyid = policy_id;
	}
	public int getUserid() {
		return userid;
	}
	public void setUserid(int user_id) {
		this.userid = user_id;
	}
	public int getDuration() {
		return duration;
	}
	public void setDuration(int duration) {
		this.duration = duration;
	}
	
	public long getAddhar_card() {
		return addhar_card;
	}
	public void setAddhar_card(long addhar_card) {
		this.addhar_card = addhar_card;
	}
	
	public SuscribePolicy(int policy_id, int user_id, int duration, long addhar_card
			) {
		super();
		this.policyid = policy_id;
		this.userid = user_id;
		this.duration = duration;
		this.addhar_card = addhar_card;
		
	}
	public SuscribePolicy() {
		super();
	}
	

}
