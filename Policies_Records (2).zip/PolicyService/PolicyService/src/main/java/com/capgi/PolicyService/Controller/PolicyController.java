package com.capgi.PolicyService.Controller;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestHeader;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.RestController;

import com.capgi.PolicyService.Entity.Policy;
import com.capgi.PolicyService.Payloads.DisplayPolicies;
import com.capgi.PolicyService.Service.PolicyService;

@RestController
@RequestMapping("/policies")
public class PolicyController {
	
	@Autowired
	private PolicyService policyService;
	
	@PostMapping("/createnewpolicy")
	public ResponseEntity<Policy> createNewPolicy(@RequestBody Policy policy){
		
		Policy policyNew = policyService.createNewPolicy(policy);
		
		return new ResponseEntity<>(policyNew, HttpStatus.CREATED);	
	}
	
	@GetMapping("/getpolicy/{policyid}")
	public ResponseEntity<Policy> getPolicy(@PathVariable int policyid){
		
		Policy policyNew = policyService.getPolicyById(policyid);
		
		return new ResponseEntity<>(policyNew, HttpStatus.FOUND);	
	}
	
	@GetMapping("/showAllPoliciesAvlForUser/{userid}")
	public ResponseEntity<DisplayPolicies> showAllPoliciesAvlForUser(@PathVariable int userid,
			@RequestParam(value="policyType", defaultValue = "ALL",required = false) String policyType
			){
		
		DisplayPolicies dp = policyService.showAllPoliciesAvlForUser(userid, policyType);
		
		return new ResponseEntity<>(dp, HttpStatus.FOUND);
	}
}
