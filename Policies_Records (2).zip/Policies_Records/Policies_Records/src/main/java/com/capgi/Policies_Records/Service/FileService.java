package com.capgi.Policies_Records.Service;

import java.io.File;
import java.io.FileInputStream;
import java.io.FileNotFoundException;
import java.io.IOException;
import java.io.InputStream;
import java.nio.file.Files;
import java.nio.file.Paths;
import java.util.UUID;

import org.springframework.stereotype.Service;
import org.springframework.web.multipart.MultipartFile;

import com.capgi.Policies_Records.Exception.ImageExtentionException;

@Service
public class FileService {
	
public String uploadImageFile(String path, MultipartFile file) throws IOException {
		
		// Get File name
		String fileName = file.getOriginalFilename();
		
		
			// Renaming file with random name
				String randomString = UUID.randomUUID().toString();
				
				String extentionCheck =  fileName.substring(fileName.lastIndexOf("."));
				
				String newFileName;
				if(extentionCheck.equals(".png") || extentionCheck.equals(".jpg")) {
					newFileName = randomString + fileName.substring(fileName.lastIndexOf("."));
				}
				else {
					throw new ImageExtentionException(fileName);
				}
				
				
		
		// Full path with file
		String filePath = path + File.separator + newFileName;
		
			
		
		
		// Creating folder if not exist
		File f = new File(path);
		if(!f.exists()) {
			f.mkdir();
		}
		
		// File copy
		Files.copy(file.getInputStream(), Paths.get(filePath));
		
		return newFileName;
	}
	
	public InputStream getResource(String path, String fileName) throws FileNotFoundException {
		
		String fileFullPath = path + File.separator + fileName;
		
		InputStream is = new FileInputStream(fileFullPath);
		
		return is;
	}

}
