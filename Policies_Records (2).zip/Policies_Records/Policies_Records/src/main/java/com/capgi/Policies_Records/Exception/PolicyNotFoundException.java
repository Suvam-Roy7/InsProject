package com.capgi.Policies_Records.Exception;

public class PolicyNotFoundException extends RuntimeException{
	
	public PolicyNotFoundException(String message) {
        super(message);
    }
}
