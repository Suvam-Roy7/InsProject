package com.capgi.Policies_Records.Service;

import java.time.LocalDate;
import java.time.ZoneId;
import java.util.Date;
import java.util.List;
import java.util.Optional;

import org.modelmapper.ModelMapper;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.web.client.RestTemplate;

import com.capgi.Policies_Records.Entity.Policy;
import com.capgi.Policies_Records.Entity.Record;
import com.capgi.Policies_Records.Entity.User;
import com.capgi.Policies_Records.Exception.PolicyNotFoundException;
import com.capgi.Policies_Records.Exception.PolicySuscribeException;
import com.capgi.Policies_Records.Payloads.SuscribePolicy;
import com.capgi.Policies_Records.Repo.RecordsRepo;

@Service
public class RecordsService {
	
	@Autowired
	private RecordsRepo recordsRepo;
	
	@Autowired
	private ModelMapper modelMapper;
	
	@Autowired
	private RestTemplate restTemplate;
	
	
	public Record suscribePolicy(SuscribePolicy suscribePolicy) {
		
		
		List<Record> userRecords = recordsRepo.findAllByUserid(suscribePolicy.getUserid());
		
		for(Record rec : userRecords) {
			if(rec.getPolicyid() == suscribePolicy.getPolicyid() && rec.getStatus().equalsIgnoreCase("Active")) {
				throw new PolicySuscribeException(suscribePolicy.getPolicyid(), suscribePolicy.getUserid());
			}
		}
		
		Policy policy = restTemplate.getForObject("http://POLICYSERVICE/policies/getpolicy/"+suscribePolicy.getPolicyid(), Policy.class);
		
		Optional.ofNullable(policy).orElseThrow(()-> new PolicyNotFoundException("Policy with ID " + suscribePolicy.getPolicyid() + " not found"));
		
		
		Record record = modelMapper.map(suscribePolicy, Record.class);
		record.setSub_date(new Date());
		record.setStatus("Active");
		
		// Convert subscription date to LocalDate
        LocalDate subDate = record.getSub_date().toInstant()
                               .atZone(ZoneId.systemDefault())
                               .toLocalDate();
        
        // Add duration to get the expiration date
        LocalDate expDate = subDate.plusDays(suscribePolicy.getDuration());

        // Convert expiration date back to Date
        record.setExp_date(Date.from(expDate.atStartOfDay(ZoneId.systemDefault()).toInstant()));
        
        recordsRepo.save(record);
        
        return record;
	}
	
	public List<Record> getAllRecords(){
		
		List<Record> records = recordsRepo.findAll();
		
		return records;
		
	}
	
	public List<Record> getUserRecords(int userid){
		
		User user = restTemplate.getForObject("http://AUTHENTICATION-SERVICE/insurance/users/getuser/"+userid, User.class);
		Optional.ofNullable(user).orElseThrow(()-> new PolicyNotFoundException("User with ID " + userid + " not found"));

		
		List<Record> records = recordsRepo.findAllByUserid(userid);
		
		return records;
	}
	
	public Record getRecordById(int recordId) {
		Record rec = recordsRepo.findById(recordId).orElseThrow(()-> new PolicyNotFoundException("Record not found !!"));
		
		return rec;
	}
	
	public Record updateRecord(int recordId, Record rec) {
		Record record = recordsRepo.findById(recordId).orElseThrow(()-> new PolicyNotFoundException("Record not found !!"));
		record.setAddharImg(rec.getAddharImg());
		
		recordsRepo.save(record);
		
		return record;
	}
}
