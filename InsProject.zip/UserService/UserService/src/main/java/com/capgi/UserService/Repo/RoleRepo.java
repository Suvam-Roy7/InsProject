package com.capgi.UserService.Repo;

import org.springframework.data.jpa.repository.JpaRepository;

import com.capgi.UserService.Entity.Role;

public interface RoleRepo extends JpaRepository<Role, Integer> {

}
